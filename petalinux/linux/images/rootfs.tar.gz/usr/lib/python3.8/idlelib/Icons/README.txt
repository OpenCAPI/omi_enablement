The IDLE icons are from https://bugs.python.org/issue1490384

Created by Andrew Clover.

The original sources are available from Andrew's website:
https://www.doxdesk.com/software/py/pyicons.html

Various different formats and sizes are available at this GitHub Pull Request:
https://github.com/python/cpython/pull/17473
